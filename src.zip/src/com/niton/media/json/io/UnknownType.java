package com.niton.media.json.io;

/**
 * This is the UnknownType Class
 * @author Nils
 * @version 2018-07-04
 */
class UnknownType {
}


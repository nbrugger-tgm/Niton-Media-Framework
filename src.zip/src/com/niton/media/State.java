package com.niton.media;

import java.io.Serializable;

public enum State  implements Serializable{
	PLAYING,
	PAUSED,
	STOPPED,
	NOT_RUNNING
}

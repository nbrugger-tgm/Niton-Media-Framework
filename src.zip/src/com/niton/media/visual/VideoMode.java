package com.niton.media.visual;

/**
 * This is the VideoMode Class
 * @author Nils
 * @version 2017-08-16
 */
public enum VideoMode {
	STREAM,
	DIRECT;
}


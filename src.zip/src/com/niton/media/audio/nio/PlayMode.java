package com.niton.media.audio.nio;

public enum PlayMode {
	/**
	 * <u><i><b>!!!Not working now!!!</b></i></u>
	 */
	PLAYLIST,
	SINGLE,
	LOOP;
}

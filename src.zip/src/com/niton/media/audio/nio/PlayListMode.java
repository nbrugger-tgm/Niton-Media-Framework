package com.niton.media.audio.nio;

public enum PlayListMode {
	LoopSingle,
	LoopAll,
	Shuffle,
	Single,
	All;
}

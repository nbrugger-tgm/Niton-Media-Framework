package com.niton.media.filesystem;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.io.Serializable;
import java.nio.ByteBuffer;
import java.nio.channels.FileChannel;
import java.nio.file.FileAlreadyExistsException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

import com.niton.media.ResurceLoader;
import com.niton.media.json.basic.JsonValue;
import com.niton.media.json.io.JsonInputStream;

public class NFile {
	private Path file;

	public NFile(String path) {
		this.file = Paths.get(path);
	}

	public NFile(String... paths) {
		String slash = System.getProperty("file.separator");
		String path = "";
		for (int i = 0; i < paths.length; i++) {
			path += paths[i] + (i + 1 < paths.length ? slash : "");
		}
		file = Paths.get(path);
	}

	public NFile(Path path) {
		file = path;
	}

	public NFile(File path) {
		file = path.toPath();
	}

	public NFile(Directory dir, String name, String ending) {
		String fullName = name + "." + ending;
		this.file = Paths.get(dir.getPathAsString(), fullName);
	}

	public NFile(Directory dir, String fullName) {
		this.file = Paths.get(dir.getPathAsString(), fullName);
	}

	public Path getPath() {
		return file;
	}

	public String getPathAsString() {
		return getPath().toString();
	}

	public Directory getParent() {
		return new Directory(getPath().getParent());
	}

	public Path getRoot() {
		return file.getRoot();
	}

	public int getDeepnes() {
		return file.getNameCount();
	}

	public String getName() {
		String filename = file.getFileName().toString();
		filename = filename.replace(getEnding(), "");
		filename = filename.substring(0, filename.length() - 1);
		return filename;
	}

	public String getEnding() {
		String filename = file.getFileName().toString();
		filename = filename.replace('.', '>');
		String[] parts = filename.split(">");
		return parts[parts.length - 1];
	}

	public String getText() throws IOException {
		String back = "";
		back = new String(Files.readAllBytes(file), "UTF-8");
		return back;
	}

	public void setText(String text) throws IOException {
		Files.write(file, text.getBytes("UTF-8"));
	}

	public void addText(String text) throws IOException {
		Files.write(file, (getText() + text).getBytes());
	}

	public void save() throws IOException {
		Files.createDirectories(file.getParent());
		Files.createFile(getPath());
	}

	public void delete() throws IOException {
		Files.delete(getPath());
	}

	public boolean exisits() {
		return Files.exists(file);
	}

	public void copyReplace(NFile target) throws IOException {
		if (target.exisits())
			target.delete();
		copy(target);
	}

	public void copy(NFile target) throws IOException {
		target.save();
		target.write(read());
	}

	public void copyBig(NFile target) {
		try {
			FileInputStream is = (FileInputStream) getInputStream();
			OutputStream stream = target.getOutputStream();
			FileChannel ch = is.getChannel();
			ByteBuffer bb = ByteBuffer.allocateDirect(1024 * 1000);
			byte[] barray = new byte[512 * 1000];
			int nRead, nGet;
			short i = 0;
			while ((nRead = ch.read(bb)) != -1) {
				i++;
				if (i == 20) {
					i = 0;
					System.gc();
				}
				if (nRead == 0)
					continue;
				bb.position(0);
				bb.limit(nRead);
				while (bb.hasRemaining()) {
					nGet = Math.min(bb.remaining(), 512 * 1000);
					bb.get(barray, 0, nGet);
					stream.write(barray);
				}
				bb.clear();
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public void moveReplace(NFile target) throws IOException {
		if (target.exisits())
			target.delete();
		move(target);
	}

	public void move(NFile target) throws IOException {
		if (target.exisits())
			throw new FileAlreadyExistsException(
					"Copy file to existing file impossible! use NFile.moveReplace(NFile) instead");
		target.save();
		target.setText(getText());
		delete();
	}

	/**
	 * Opens and returns an stream FROM the file
	 * 
	 * @author Nils
	 * @version 2017-08-18
	 * @return the stream FROM the NFile
	 * @throws FileNotFoundException
	 *             if the file is not found you cannot open an Stream
	 */
	public FileInputStream getInputStream() throws FileNotFoundException {
		return new FileInputStream(getFile());
	}

	/**
	 * Opens and returns an stream TO the file
	 * 
	 * @author Nils
	 * @version 2017-08-18
	 * @return the stream TO the NFile
	 * @throws FileNotFoundException
	 *             if the file is not found you cannot open an Stream
	 */
	public FileOutputStream getOutputStream() throws FileNotFoundException {
		return new FileOutputStream(getFile());
	}

	/**
	 * Returns the object as File
	 * 
	 * @author Nils
	 * @version 2017-08-18
	 * @return the file
	 */
	public File getFile() {
		return getPath().toFile();
	}

	/**
	 * Renames the file to the given name.
	 * 
	 * @author Nils
	 * @version 2017-08-18
	 * @param newName
	 *            the new Name for the file
	 * @throws IOException
	 *             read write error
	 * @throws FileAlreadyExistsException
	 *             if there is allready an file with this name
	 */
	public void rename(String newName) throws IOException, FileAlreadyExistsException {
		move(new NFile(getParent(), newName));
	}

	/**
	 * Description : <br>
	 * Writes the bytes bytewhise to the file
	 * 
	 * @author Nils
	 * @version 2017-08-18
	 * @param content
	 *            all bytes write to the file
	 * @throws IOException
	 *             all errors my happen
	 */
	public void write(byte[] content) throws IOException {
		try {
			FileOutputStream os = new FileOutputStream(getFile());
			System.out.println("write " + content.length / 1000 + " MB");
			BufferedOutputStream bos = new BufferedOutputStream(os);
			bos.write(content);
			bos.flush();
			bos.close();
		} catch (FileNotFoundException e) {
			System.out.println("File not found");
			save();
		}

	}

	/**
	 * Description : <br>
	 * Reads the bytes bytewhise to the file We use the fastest way to read the
	 * file.<br>
	 * File Reading: <a href=
	 * "http://nadeausoftware.com/articles/2008/02/java_tip_how_read_files_quickly">http://nadeausoftware.com/articles/2008/02/java_tip_how_read_files_quickly</a>
	 * 
	 * @author Nils
	 * @version 2017-08-18
	 * @return the content redden from the file or new byte[0] on any error
	 */
	public byte[] read() {
		try {
			return Files.readAllBytes(file);
		} catch (IOException e) {
			System.out.println("Error : return new byte[0]");
			e.printStackTrace();
			return new byte[0];
		}
	}

	/**
	 * Returns the path to the file.
	 * 
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return getPathAsString();
	}

	public String getAbsolutePath() {
		return getAbsolutePath();
	}

	public void write(Serializable data) throws IOException {
		write(ResurceLoader.serialize(data));
	}

	public Serializable readData() throws ClassNotFoundException, IOException {
		return ResurceLoader.deSerialize(read());
	}

	public void write(JsonValue<?> object) {
		try {
			Files.write(file, object.getJson().getBytes("UTF-8"));
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public JsonValue<?> readJson() {
		try {
			JsonInputStream jis = new JsonInputStream(this);
			JsonValue<?> calue = jis.readNextJson();
			jis.close();
			return calue;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}
}
